import React from 'react'

export default function Partners() {
    return (
        <>
            <div className="partner-area pt-negative">
                <div className="container-fluid">
                    <div className="col-lg-8">
                        <div className="partner-wrap">
                            <div className="partner-wrapper flex justify-center ">
                                <h1 className='font-extrabold'>TapTay</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
